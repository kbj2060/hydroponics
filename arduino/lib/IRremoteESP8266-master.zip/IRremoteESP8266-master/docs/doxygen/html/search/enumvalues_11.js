var searchData=
[
  ['unknown_7113',['UNKNOWN',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada6ce26a62afab55d7606ad4e92428b30c',1,'IRremoteESP8266.h']]],
  ['unused_7114',['UNUSED',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadaa09b651ef326a9d8efcee5cc5b720ab4',1,'IRremoteESP8266.h']]]
];
