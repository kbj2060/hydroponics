var searchData=
[
  ['magiquest_3574',['magiquest',['../unionmagiquest.html',1,'']]],
  ['match_5fresult_5ft_3575',['match_result_t',['../structmatch__result__t.html',1,'']]]
];
